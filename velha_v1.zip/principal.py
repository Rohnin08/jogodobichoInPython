"""Interface de texto para o Jogo da Velha"""


import velha


# FUNÇÕES DE ENTRADA E SAÍDA DE TEXTO

def jogar():
    '''Executa uma partida completa do Jogo da Velha.'''
    # Inicialização das variáveis
    # Escolhe o jogador que começa
    jogador = velha.sortear_jogador()
    # O vencedor pode ser 'X', 'O', '=' (empate) ou '' (indefinido, ainda está jogando)
    vencedor = velha.JOGANDO
    tabuleiro = velha.novo_tabuleiro()
    # Aqui começa o jogo
    while vencedor == velha.JOGANDO:
        exibir_tabuleiro(tabuleiro)
        jogada = pedir_jogada(jogador, tabuleiro)
        velha.marcar_jogada(tabuleiro, jogada, jogador)
        vencedor = velha.verificar_vencedor(tabuleiro)
        jogador = velha.trocar_jogador(jogador)

    # Exibe o resultado do jogo
    exibir_tabuleiro(tabuleiro)
    if vencedor == velha.EMPATE:
        print('Deu velha!')
    else:
        print(f'O {vencedor} venceu!')
    
    # Adiciona ao registro de pontuações
    nome = input('Digite seu nome: ')
    pontuacao = velha.calcular_pontuacao(tabuleiro)
    velha.registrar_pontuacao(nome, pontuacao)

    exibir_ranking()


def exibir_tabuleiro(tabuleiro: list[str]):
    '''Exibe o tabuleiro no formato do teclado numérico.
    
    Parâmetros:
      - tabuleiro: o tabuleiro do jogo.'''
    # Os números de cima são mais altos, por isso o i vai diminuindo
    for i in range(2,-1,-1):
        for j in range(3):
            # Exibe a posição ou a marca do jogador
            posicao = 3 * i + j
            marca = tabuleiro[posicao]
            if marca == velha.B:
                marca = str(posicao + 1)
            fim = '|'  # Imprime a barra vertical
            if j >= 2:
                fim = '\n'  # Quebra a linha no final
            print(marca, end=fim)
        if i > 0:
            print('-+-+-')


def exibir_ranking():
    '''Exibe o ranking dos melhores jogadores.'''
    print('RANKING DOS MELHORES JOGADORES')
    ranking = velha.calcular_ranking()
    for jogador in ranking[:10]:
        nome = jogador['nome']
        pontos = jogador['pontos']
        print(f'{nome} - {pontos}')


def pedir_jogada(jogador: str, tabuleiro: list[str]) -> int:
    '''Pede uma jogada válida, ou seja, o índice de uma posição com `B` no tabuleiro.

    Parâmetros:
      - `jogador`: o jogador atual.
      - `tabuleiro`: o tabuleiro do jogo.
    
    Retorna:
      Uma jogada válida.
    '''
    jogada = -1
    valida = False
    while not valida:
        # Pede a jogada
        jogada = int(input(f'Onde você quer jogar ({jogador})? ')) - 1
        # Verifica se a jogada é válida
        if jogada < 0 or jogada > 8:
            # Jogada inválida, fora do tabuleiro
            print(f'Índice {jogada} fora do tabuleiro [1-9].')
        elif tabuleiro[jogada] in [velha.X, velha.O]:
            # Jogada inválida, índice ocupado
            print('Esta casa já está ocupada.')
        else:
            # Jogada válida, encerra o laço
            valida = True
    return jogada



# PROGRAMA PRINCIPAL

if __name__ == '__main__':
    jogar()