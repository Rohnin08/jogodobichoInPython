"""Jogo da Velha"""

import random


# CONSTANTES GLOBAIS

# Jogadores
X = 'X'
O = 'O'

# Casa em branco
B = ''

# Resultados do jogo
EMPATE = '='
JOGANDO = ''


# FUNÇÕES DE LÓGICA DO JOGO

def novo_tabuleiro() -> list[str]:
    '''Cria um novo tabuleiro.

    O tabuleiro é uma lista de strings representando as casas.
    Cada casa contém `X`, `O` ou `B`.
    Ex.: a lista `[X, B, O, B, O, B, O, X, X]` corresponde ao jogo abaixo:
    ```
    O|X|X
    -+-+-
    4|O|6
    -+-+-
    X|2|O
    ```
    
    Retorna:
      Um tabuleiro em branco (todas as casas `B`).
    '''
    tabuleiro = [B] * 9
    return tabuleiro


def marcar_jogada(tabuleiro, jogada, jogador):
    '''Marca o `tabuleiro` na casa `jogada` com o símbolo do `jogador`.'''
    tabuleiro[jogada] = jogador


def sortear_jogador() -> str:
    '''Retorna um jogador, `X` ou `O`, escolhido aleatoriamente.'''
    return random.choice([X, O])


def verificar_vencedor(tabuleiro: list[str]) -> str:
    '''Verifica se houve um vencedor no jogo.

    Retorna:
    - `X`, se ele for o vencedor (análogo para `O`).
    - `EMPATE`, se o jogo estiver empatado.
    - `JOGANDO`, se ainda houver posições a jogar.
    '''
    # Booleano para guardar se o jogo foi empate.
    # Assume que está empatado até que se verifique que não está.
    empatado = True
    # Lista com todas as verificações necessárias para detectar um vencedor.
    verificacoes = [
        [0,1,2], [3,4,5], [6,7,8],  # linhas
        [0,3,6], [1,4,7], [2,5,8],  # colunas
        [0,4,8], [2,4,6]            # diagonais
    ]
    # Executar todas as verificações
    for v in verificacoes:
        temp = verificar(*v, tabuleiro)
        if temp in [X, O]:
            # Um jogador venceu, retorna o vencedor
            return temp
        empatado = empatado and temp == EMPATE
    if empatado:
        return EMPATE
    return JOGANDO


def verificar(p1: int, p2: int, p3: int, tabuleiro: list[str]) -> str:
    '''Verifica se uma sequência (p1, p2, p3) no tabuleiro contém um vencedor.

    Parâmetros:
      - `p1`, `p2` e `p3`: Posições no tabuleiro para verificar.
      - `tabuleiro`: O tabuleiro.

    Retorno:
      - `X` (ou `O`) caso este seja o vencedor.
      - `EMPATE` caso a sequência esteja toda preenchida e não haja vencedor.
      - `JOGANDO` (vazio) caso ainda haja elementos a preencher na sequência.
    '''
    marca1 = tabuleiro[p1]
    marca2 = tabuleiro[p2]
    marca3 = tabuleiro[p3]
    if marca1 == marca2 == marca3:
        return marca1
    if marca1 == B or marca2 == B or marca3 == B:
        return JOGANDO
    return EMPATE


def trocar_jogador(atual: str) -> str:
    '''Dado o jogador `atual`, retorna o próximo jogador.
    Ex.: se `atual == X`, retorna `O`.'''
    if atual == O:
        return X
    return O


def calcular_pontuacao(tabuleiro: list[str]) -> int:
    '''Calcula a pontuação obtida pelo jogador ao vencer.
    
    A pontuação é dada por:
      - +10 pontos pela vitória.
      - +10 pontos por cada casa que ficou vazia.
        Dessa forma recompensamos jogadores que gastam menos jogadas para vencer.
    
    Parâmetros:
      - `tabuleiro`: O tabuleiro do jogo. Assume-se que está em estado de vitória de um dos jogadores.
    
    Retorna:
      A quantidade de pontos obtida pela vitória.
    '''
    pontos = 10  # Começa valendo 10 pontos pela simples vitória
    for casa in tabuleiro:
        # Soma +10 por cada casa em branco
        if casa == B:
            pontos += 10
    return pontos


def registrar_pontuacao(nome, pontuacao):
    '''Registra o `nome` e a `pontuacao` no arquivo de pontuações.'''
    arq = open('pontuacoes.txt', 'a')
    arq.write(f'{nome}\n{pontuacao}\n')
    arq.close()


def calcular_ranking() -> list[dict]:
    '''Calcula o ranking dos melhores jogadores.
    
    Retorna:
      A lista ordenada de jogadores, representados como um dicionário `{'nome': ..., 'pontos': ...}`.
    '''
    # Lê o arquivo de pontuações
    arq = open('pontuacoes.txt')
    linhas = arq.readlines()
    arq.close()
    # Calcula o total de cada jogador
    totais = {}
    for i in range(0, len(linhas), 2):
        nome = linhas[i][:-1]
        pontos = int(linhas[i+1])
        if nome not in totais:
            totais[nome] = 0
        totais[nome] += pontos
    # Cria o ranking desordenado
    ranking = []
    for nome, total in totais.items():
        # Representa cada jogador como um dicionário
        jogador = {'nome': nome, 'pontos': total}
        ranking += [jogador]
    # Ordena o ranking
    for i in range(len(ranking)):
        for j in range(i+1, len(ranking)):
            jog1 = ranking[i]
            jog2 = ranking[j]
            if jog1['pontos'] < jog2['pontos']:
                aux = ranking[i]
                ranking[i] = ranking[j]
                ranking[j] = aux
    return ranking
